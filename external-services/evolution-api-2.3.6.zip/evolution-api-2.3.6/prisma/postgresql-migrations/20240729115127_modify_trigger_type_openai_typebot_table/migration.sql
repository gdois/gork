-- AlterEnum
ALTER TYPE "TriggerType" ADD VALUE 'none';
